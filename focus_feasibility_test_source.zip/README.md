# Focus Feasibility Test (Android)

**Purpose:** a small, local-only feasibility prototype for an Android phone. It tests:
1. Whether Android Usage Access allows the app to query recent app-usage summaries.
2. Whether an explicitly enabled Accessibility Service can detect foreground package changes and show a dismissible intervention for user-selected test packages.

This is **not** the full distraction-reduction app and is **not** tamper-proof blocking. The app does not upload usage data.

## Important limitations

- This environment did not have the Android SDK or Gradle installed, so an APK has not been compiled or device-tested here.
- The source targets compile SDK 36 and Android Gradle Plugin 8.10.1; Android Studio may need to download the required SDK/build components.
- Accessibility-based monitoring is a feasibility candidate, not a final architectural decision. Review current Google Play policy and use only with informed user consent. If publishing publicly, this approach may require redesign.
- The overlay is a test intervention, not a guarantee that a selected app cannot be accessed or bypassed.
- Do not add critical apps, Settings, the launcher, dialer, emergency apps, or system UI to the test list.
- OEM power management may stop or delay behavior. This must be measured on the actual phone.

## Build with Android Studio

1. Install a current Android Studio version with JDK 17 support.
2. Open this folder as an existing Android project.
3. Allow Gradle sync and install the Android SDK Platform 36 if prompted.
4. Connect the Vivo phone with USB debugging enabled, or use Android Studio's normal device-install workflow.
5. Build and install the `app` run configuration.

The prototype is not signed for public distribution. Do not install builds from untrusted sources.

## Test procedure

### A. Usage access
1. Open the app.
2. Tap **Open Usage Access settings**.
3. Select **Focus Feasibility Test** and enable **Allow usage access**.
4. Return to the app and tap **Check permission and load last 24h**.
5. Use a few ordinary apps for several minutes, then refresh.
6. Compare broad totals with Android's own usage display. Small differences can occur due to intervals, rounding and system reporting.

Record: permission granted? results present? plausible package names/durations? refresh after app use?

### B. Foreground detection / intervention
1. Choose one nonessential app and identify its package ID. A package ID is not necessarily its visible app name.
2. Enter only that package ID in **Packages to test** and tap **Save test list**.
3. Tap **Open Accessibility settings**.
4. Enable **Focus Feasibility Test — App Watch**. Read Android's disclosure carefully; this grants the service visibility into window/app transition events.
5. Return to the test app, then open the selected test app.
6. Confirm that the intervention appears and that it disappears when you leave the selected app.
7. Test several app switches, screen off/on, backgrounding and reboot separately.
8. To stop monitoring, disable the service in Accessibility settings or remove the package from the test list.

**Recovery:** the overlay has a dismiss button. If anything behaves unexpectedly, disable the accessibility service from Android Settings. Do not test with a critical app.

## Results log template

- Phone model and OS/build:
- Usage Access granted:
- Usage results appeared:
- Data plausibility:
- Test package:
- Intervention appeared:
- Intervention cleared after leaving app:
- Screen-off/on result:
- Background result:
- Reboot result:
- Battery / lag observations:
- Errors or unexpected behavior:

## Data and privacy

All test package choices are stored in local app preferences. Usage summaries are queried from Android on demand and displayed locally. No analytics or network requests are implemented in this prototype.
