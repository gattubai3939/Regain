package com.example.focusfeasibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Feasibility-only foreground package detector.
 *
 * The intervention is intentionally a dismissible, user-visible overlay.
 * This prototype does not attempt to prevent uninstalling, alter system settings,
 * or block critical system apps. Always test with a nonessential app.
 */
class AppWatchAccessibilityService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var overlay: android.view.View? = null
    private var overlayForPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOWS_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = 0
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName || MainActivity.isCriticalPackage(pkg)) {
            removeOverlay()
            return
        }

        val configured = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
            .getString(MainActivity.KEY_BLOCKED, "")
            .orEmpty()
            .split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toSet()

        if (pkg in configured) {
            showOverlay(pkg)
        } else if (overlayForPackage != null && overlayForPackage != pkg) {
            removeOverlay()
        }
    }

    private fun showOverlay(pkg: String) {
        if (overlayForPackage == pkg && overlay != null) return
        removeOverlay()

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(0xEE172033.toInt())
        }
        panel.addView(TextView(this).apply {
            text = "Focus test intervention"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        })
        panel.addView(TextView(this).apply {
            text = "\nYou opened a test-blocked app:\n$pkg\n\nThis is a feasibility prototype, not tamper-proof blocking."
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        })
        panel.addView(Button(this).apply {
            text = "Dismiss test overlay"
            setOnClickListener { removeOverlay() }
        })
        panel.addView(TextView(this).apply {
            text = "To leave the test, use the phone's normal Home/Back controls. Remove this package from the test list to stop future interventions."
            textSize = 12f
            setTextColor(0xFFDFE6F2.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        })

        val type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        try {
            windowManager?.addView(panel, params)
            overlay = panel
            overlayForPackage = pkg
        } catch (_: Exception) {
            // Keep the service alive; the main screen can report service status.
        }
    }

    private fun removeOverlay() {
        val old = overlay ?: run {
            overlayForPackage = null
            return
        }
        try {
            windowManager?.removeView(old)
        } catch (_: Exception) {
        } finally {
            overlay = null
            overlayForPackage = null
        }
    }

    override fun onInterrupt() {
        removeOverlay()
    }

    override fun onDestroy() {
        isRunning = false
        removeOverlay()
        super.onDestroy()
    }

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
    }
}
