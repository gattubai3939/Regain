package com.example.focusfeasibility

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var packageInput: EditText
    private lateinit var results: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 24)
        }
        scroll.addView(content)

        content.addView(TextView(this).apply {
            text = "Focus Feasibility Test"
            textSize = 24f
        })
        content.addView(TextView(this).apply {
            text = "Prototype only. It tests usage access and foreground-app detection; it is not a complete blocker."
            textSize = 14f
            setPadding(0, 12, 0, 20)
        })

        status = TextView(this).apply { textSize = 16f }
        content.addView(status)

        content.addView(button("Open Usage Access settings") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        content.addView(button("Check permission and load last 24h") {
            refreshUsage()
        })

        content.addView(TextView(this).apply {
            text = "Packages to test (comma-separated)"
            textSize = 16f
            setPadding(0, 20, 0, 8)
        })
        packageInput = EditText(this).apply {
            hint = "e.g. com.example.app"
            setText(prefs().getString(KEY_BLOCKED, ""))
            setSingleLine(false)
            minLines = 2
        }
        content.addView(packageInput)
        content.addView(button("Save test list") {
            val packages = packageInput.text.toString()
                .split(",", "\n")
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .filterNot { it == packageName || isCriticalPackage(it) }
                .distinct()
            prefs().edit().putString(KEY_BLOCKED, packages.joinToString(",")).apply()
            packageInput.setText(packages.joinToString(", "))
            status.text = "Saved ${packages.size} test package(s). Accessibility monitoring must be enabled separately."
        })
        content.addView(button("Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        content.addView(button("Refresh usage results") { refreshUsage() })

        results = TextView(this).apply {
            textSize = 13f
            setPadding(0, 16, 0, 0)
        }
        content.addView(results)

        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
        refreshUsage()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun refreshUsage() {
        updatePermissionStatus()
        if (!hasUsageAccess()) {
            results.text = "Grant Usage Access, return here, then tap Refresh usage results."
            return
        }
        try {
            val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val start = end - 24L * 60L * 60L * 1000L
            val stats: List<UsageStats> = manager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, start, end
            ) ?: emptyList()

            val lines = stats
                .filter { it.totalTimeInForeground > 0L }
                .sortedByDescending { it.totalTimeInForeground }
                .take(30)
                .map {
                    "${it.packageName}\n  Foreground: ${formatDuration(it.totalTimeInForeground)}"
                }
            results.text = if (lines.isEmpty()) {
                "No usage rows returned for this period. Use a few apps, then refresh. Some devices may return limited or delayed history."
            } else {
                "Top app usage rows (last 24 hours; system-reported):\n\n" + lines.joinToString("\n\n")
            }
        } catch (e: Exception) {
            results.text = "Usage query failed: ${e.javaClass.simpleName}: ${e.message ?: "no details"}"
        }
    }

    private fun updatePermissionStatus() {
        val usage = if (hasUsageAccess()) "GRANTED" else "NOT GRANTED"
        val accessibility = if (AppWatchAccessibilityService.isRunning) "connected" else "not detected as connected"
        status.text = "Usage Access: $usage\nApp watch service: $accessibility"
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun formatDuration(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
    }

    private fun prefs() = getSharedPreferences(PREFS, MODE_PRIVATE)

    companion object {
        const val PREFS = "focus_feasibility"
        const val KEY_BLOCKED = "blocked_packages"
        fun isCriticalPackage(pkg: String): Boolean {
            val lower = pkg.lowercase()
            return lower.startsWith("com.android.systemui") ||
                lower == "com.android.settings" ||
                lower.contains("permissioncontroller") ||
                lower.contains("packageinstaller") ||
                lower.contains("emergency") ||
                lower.contains("dialer")
        }
    }
}
